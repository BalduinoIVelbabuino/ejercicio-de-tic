<!DOCTYPE html>   

<html>  

<head>   

<title>Javascript</title>  

 <script type="text/javascript"> alert(“Hola Mundo”);</script>   <!--script embebido-->  

</head>   

  <body>  

<h1>¿Dónde uso Javascript?</h1>  

<script src = " js-ejerc01-primer_programa.js "></script><!--script externo al html-->  

        </body>  

</html>